"use client";

import { useLayoutEffect, useRef, useState, type Ref, type RefObject } from "react";
import gsap from "gsap";
import type { Job } from "@/lib/careers/jobs";
import { useMagnetic } from "@/lib/hooks/use-magnetic";
import { createOrbitLayout, type OrbitLayout } from "@/lib/carousel/orbit";
import { onIntroReveal } from "@/lib/intro/reveal-signal";
import { EASE, prefersReducedMotion } from "@/lib/motion";
import { JobCard } from "./JobCard";

// The orbit: every role at an equal angle round one ellipse through the
// cards' centreline, so there is no first or last card. Geometry, spacing
// and visibility live in lib/carousel/orbit.ts.
/** Camera distance (px), from one point at the stage centre for every card. */
const PERSPECTIVE = 1600;
/** Projected gap between the front card and its neighbours (px), roomier on wide stages. */
const GAP = 30;
const GAP_COMPACT = 16;
/** Below this stage width (px) the compact gap applies. */
const COMPACT_WIDTH = 768;
/** The orbit's depth as a share of its width: neighbours turn about 19°, the next cards about 46°. */
const ORBIT_DEPTH = 0.72;
/** How much smaller a card is at the very back of the orbit, on top of perspective. */
const DEPTH_SHRINK = 0.10;
/** Seconds between automatic steps, while nobody is interacting. */
const AUTO_ROTATE = 5;
/** Most cards a flick can carry the orbit past: keeps momentum controlled. */
const MAX_GLIDE = 0.65;
/** Pixels of movement before a press becomes a drag. */
const DRAG_THRESHOLD = 6;
/** How far the hovered card comes forward (px): gentle, it stays in orbit. */
const HOVER_LIFT = 12;

type Engine = {
  setCount: (count: number) => void;
  step: (delta: number) => void;
  destroy: () => void;
};

type JobCarouselProps = {
  jobs: Job[];
  onClear: () => void;
  ref?: Ref<HTMLElement>;
};

/**
 * Roles on an endless 3D orbit. One animation loop owns all motion: the
 * orbit's rotation eases toward a target that dragging (with momentum),
 * horizontal wheel, arrow keys, focus and a slow auto-rotation all move.
 * The rotation is a continuous number that is never reset, so the orbit
 * turns through any number of revolutions without a jump. It writes
 * transforms straight to the DOM and sleeps when settled, so React only
 * re-renders when the front role changes.
 */
export function JobCarousel({ jobs, onClear, ref }: JobCarouselProps) {
  const stage = useRef<HTMLDivElement>(null);
  const slots = useRef<(HTMLDivElement | null)[]>([]);
  const live = useRef<HTMLParagraphElement>(null);
  const engine = useRef<Engine | null>(null);
  const [active, setActive] = useState(0);
  const prev = useMagnetic<HTMLButtonElement>(0.35);
  const next = useMagnetic<HTMLButtonElement>(0.35);

  useLayoutEffect(() => {
    const el = stage.current;
    if (!el) return;
    engine.current = createEngine(el, slots.current, live, setActive);
    return () => {
      engine.current?.destroy();
      engine.current = null;
    };
  }, []);

  // A new set of roles (filters changed): the orbit re-forms around them.
  useLayoutEffect(() => {
    slots.current.length = jobs.length;
    engine.current?.setCount(jobs.length);
  }, [jobs]);

  const count = jobs.length;
  const current = count > 0 ? jobs[Math.min(active, count - 1)] : undefined;

  return (
    <section ref={ref} id="roles" tabIndex={-1} aria-roledescription="carousel" aria-label="Open roles" className="relative scroll-mt-24 outline-none">
      {/* The stage stays mounted when nothing matches: the engine is bound to it. */}
      <div
        ref={stage}
        role="group"
        tabIndex={count > 0 ? 0 : -1}
        aria-label="Roles. Use the left and right arrow keys to turn the carousel."
        className={`relative h-[calc(var(--card-h)+10rem)] touch-pan-y select-none rounded-[40px] outline-none [--card-h:calc(var(--card-w)*0.66)] [--card-w:min(84vw,30rem)] focus-visible:outline-2 focus-visible:-outline-offset-8 focus-visible:outline-gold/60 lg:[--card-w:clamp(28rem,33vw,40rem)] ${
          count > 1 ? "cursor-grab data-[dragging=true]:cursor-grabbing data-[dragging=true]:**:cursor-grabbing" : ""
        }`}
      >
        {/* The gallery floor: a soft shadow the orbit turns above. */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute bottom-6 left-1/2 h-28 w-[min(90vw,80rem)] -translate-x-1/2 bg-[radial-gradient(closest-side,rgb(20_21_24/0.12),transparent)]"
        />
        {/* One shared perspective for every orbital card. */}
        <div
          className="absolute inset-0"
          style={{ perspective: `${PERSPECTIVE}px`, perspectiveOrigin: "50% 50%" }}
        >
          {jobs.map((job, i) => (
            <div
              key={job.slug}
              ref={(node) => {
                slots.current[i] = node;
              }}
              data-index={i}
              role="group"
              aria-roledescription="slide"
              aria-label={`${i + 1} of ${count}`}
              className="group/slot absolute left-1/2 top-1/2 w-(--card-w) origin-center opacity-0 will-change-transform [transform-style:preserve-3d]"
              style={{ translate: "-50% -50%" }}
            >
              <div
                data-tilt
                className="transition-transform duration-700 ease-premium [transform-style:preserve-3d] [transform:translateZ(var(--lift,0px))_rotateX(var(--rx,0deg))_rotateY(var(--ry,0deg))]"
              >
                <JobCard job={job} />
              </div>
            </div>
          ))}
        </div>

        {count === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center px-(--gutter) text-center">
            <p className="font-serif text-[clamp(2.5rem,5vw,4.5rem)] italic leading-none tracking-[-0.02em]">Nothing here, yet.</p>
            <p className="mt-4 max-w-sm text-muted">No roles match these filters right now. Try widening your search.</p>
            <button
              type="button"
              onClick={onClear}
              className="mt-8 cursor-pointer rounded-full bg-ink px-6 py-3 text-sm font-medium text-white transition-colors hover:bg-black"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>

      {current && (
        <div className="mt-2 grid grid-cols-[1fr_auto] items-center gap-6 px-(--gutter) lg:grid-cols-[1fr_auto_1fr]">
          <div className="flex min-w-0 items-baseline gap-4">
            <span className="font-serif text-4xl italic leading-none tabular-nums">{String(active + 1).padStart(2, "0")}</span>
            <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-muted">/ {String(count).padStart(2, "0")}</span>
            {/* Announced when the visitor turns the orbit, never for auto-rotation. */}
            <p ref={live} aria-live="off" className="hidden min-w-0 truncate text-sm text-foreground/70 sm:block">
              {current.title} <span className="text-muted">— {current.property}</span>
            </p>
          </div>
          <div aria-hidden="true" className="relative hidden h-px w-[min(24rem,26vw)] bg-line lg:block">
            <span
              className="absolute -top-px h-[3px] rounded-full bg-gold transition-[left] duration-700 ease-premium"
              style={{ width: `${100 / count}%`, left: `${(active / count) * 100}%` }}
            />
          </div>
          <div className="flex items-center justify-end gap-5">
            <span className="hidden font-mono text-[10.5px] uppercase tracking-[0.16em] text-muted xl:inline">Drag · Scroll · ← →</span>
            <div className="flex gap-2">
              {(
                [
                  { label: "Previous role", delta: -1, path: "M10 3 5 8l5 5", ref: prev },
                  { label: "Next role", delta: 1, path: "m6 3 5 5-5 5", ref: next },
                ] as const
              ).map(({ label, delta, path, ref: magnet }) => (
                <button
                  key={label}
                  ref={magnet}
                  type="button"
                  aria-label={label}
                  onClick={() => engine.current?.step(delta)}
                  disabled={count < 2}
                  className="flex size-13 cursor-pointer items-center justify-center rounded-full border border-foreground/15 bg-white/60 text-foreground transition-[background-color,color,border-color,opacity] duration-500 ease-premium hover:border-ink hover:bg-ink hover:text-gold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold disabled:pointer-events-none disabled:opacity-30"
                >
                  <svg viewBox="0 0 16 16" aria-hidden="true" className="size-4">
                    <path d={path} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
const preventDefault = (event: Event) => event.preventDefault();

/** All carousel motion. Lives outside React: it touches only the DOM. */
function createEngine(
  stage: HTMLDivElement,
  slots: (HTMLDivElement | null)[],
  live: RefObject<HTMLParagraphElement | null>,
  onActive: (index: number) => void,
): Engine {
  const reduced = prefersReducedMotion();

  let count = 0;
  // Rotation in card steps: unbounded, never wrapped. Card i is at the front
  // whenever `current` is any i + k·count.
  let current = 0;
  let target = 0;
  let activeIndex = -1;
  /** Whether the next change of front card came from the visitor (announce it). */
  let announce = false;
  /** 0 → 1: the cards fanning out of the depth into the orbit. */
  const intro = { value: reduced ? 1 : 0 };
  let layout: OrbitLayout | null = null;

  let pressed = false;
  let dragging = false;
  let moved = false;
  let startX = 0;
  let startTarget = 0;
  let samples: { x: number; t: number }[] = [];

  let hovered = -1;
  let pointerInside = false;
  let focusInside = false;
  let onScreen = true;

  let frame = 0;
  let last = 0;
  let wheelTimer = 0;

  /** Card i's offset from the front, wrapped to the shorter way round. */
  const offset = (i: number) => {
    const d = (((i - current) % count) + count) % count;
    return d > count / 2 ? d - count : d;
  };
  /** Projected distance between neighbours' centres (px): one step of drag. */
  const stride = () => layout?.stride ?? 500;

  function render() {
    if (!layout) return;
    const front = ((Math.round(current) % count) + count) % count;

    for (let i = 0; i < count; i++) {
      const slot = slots[i];
      if (!slot) continue;
      const d = offset(i);
      const place = layout.place(d);
      // Entrance: each card rises into place a beat after the one in front
      // of it. Only opacity and height change, so the orbit's spacing holds.
      const t = clamp(intro.value * 1.35 - Math.abs(d) * 0.1, 0, 1);
      const opacity = place.opacity * t;

      // The parent supplies a single consistent camera/perspective.
      // Card, curved cutout, title and CTA remain one orbital 3D unit.
      slot.style.transform = `translate3d(${place.x.toFixed(2)}px, ${((1 - t) * 60).toFixed(2)}px, ${place.z.toFixed(2)}px) rotateY(${place.rotateY.toFixed(3)}deg) scale(${place.scale.toFixed(4)})`;
      slot.style.opacity = opacity.toFixed(3);
      slot.style.visibility = opacity < 0.015 ? "hidden" : "visible";
      slot.style.pointerEvents = opacity < 0.65 ? "none" : "";
      slot.style.zIndex = String(place.zIndex);
      // Depth fade: further round the orbit, the card washes toward the page.
      slot.style.setProperty("--veil", place.fade.toFixed(3));
      const isActive = String(i === front && t > 0.6);
      if (slot.dataset.active !== isActive) slot.dataset.active = isActive;
    }

    if (front !== activeIndex && count > 0) {
      activeIndex = front;
      live.current?.setAttribute("aria-live", announce ? "polite" : "off");
      onActive(front);
    }
  }

  function tick(now: number) {
    const dt = Math.min(0.05, (now - last) / 1000 || 1 / 60);
    last = now;
    // While dragging the orbit follows the pointer exactly; otherwise it
    // eases to its target without overshooting.
    const ease = reduced || dragging ? 1 : 1 - Math.exp(-dt * 6);
    current += (target - current) * ease;
    const settled = !dragging && Math.abs(target - current) < 0.0004;
    if (settled) current = target;
    render();
    frame = settled ? 0 : requestAnimationFrame(tick);
  }

  function kick() {
    if (frame || count === 0) return;
    last = performance.now();
    frame = requestAnimationFrame(tick);
  }

  /** Turn to card `index` the shorter way round. */
  function goTo(index: number) {
    if (count === 0) return;
    const d = (((index - target) % count) + count) % count;
    target += d > count / 2 ? d - count : d;
    kick();
  }

  function stepBy(delta: number, byVisitor: boolean) {
    if (count < 2) return;
    announce = byVisitor;
    target = Math.round(target) + delta;
    kick();
  }

  function setHovered(index: number) {
    if (index === hovered) return;
    const previous = slots[hovered]?.querySelector<HTMLElement>("[data-tilt]");
    previous?.style.setProperty("--lift", "0px");
    previous?.style.setProperty("--rx", "0deg");
    previous?.style.setProperty("--ry", "0deg");
    previous?.style.setProperty("--px", "0");
    previous?.style.setProperty("--py", "0");
    hovered = index;
    if (index >= 0 && !reduced) slots[index]?.querySelector<HTMLElement>("[data-tilt]")?.style.setProperty("--lift", `${HOVER_LIFT}px`);
  }

  const slotIndex = (el: EventTarget | null) => {
    const slot = (el as Element | null)?.closest?.<HTMLElement>("[data-index]");
    return slot ? Number(slot.dataset.index) : -1;
  };

  function onPointerDown(event: PointerEvent) {
    if (event.button !== 0) return;
    pressed = true;
    moved = false;
    startX = event.clientX;
    // Freeze the position that is ACTUALLY rendered, not a future snap target.
    startTarget = current;
    target = current;
    samples = [{ x: event.clientX, t: event.timeStamp }];
  }

  function onPointerMove(event: PointerEvent) {
    if (pressed && count > 1) {
      const dx = event.clientX - startX;
      if (!dragging && Math.abs(dx) > DRAG_THRESHOLD) {
        dragging = true;
        moved = true;
        announce = true;
        stage.dataset.dragging = "true";
        stage.setPointerCapture(event.pointerId);
        setHovered(-1);
      }
      if (dragging) {
        target = startTarget - dx / stride();
        samples.push({ x: event.clientX, t: event.timeStamp });
        while (samples.length > 2 && event.timeStamp - samples[0].t > 100) samples.shift();
        kick();
      }
    }

    if (!dragging && event.pointerType === "mouse") {
      const index = slotIndex(event.target);
      setHovered(index);
      // A subtle tilt toward the cursor; the card's photo reads --px/--py for parallax.
      const tilt = index >= 0 && !reduced ? slots[index]?.querySelector<HTMLElement>("[data-tilt]") : null;
      if (tilt) {
        const card = tilt.getBoundingClientRect();
        const nx = clamp((event.clientX - card.left) / card.width - 0.5, -0.5, 0.5);
        const ny = clamp((event.clientY - card.top) / card.height - 0.5, -0.5, 0.5);
        tilt.style.setProperty("--ry", `${(nx * 5).toFixed(2)}deg`);
        tilt.style.setProperty("--rx", `${(-ny * 4).toFixed(2)}deg`);
        tilt.style.setProperty("--px", nx.toFixed(3));
        tilt.style.setProperty("--py", ny.toFixed(3));
      }
    }
  }

  function onPointerUp(event: PointerEvent) {
    if (!pressed) return;
    pressed = false;
    if (!dragging) return;
    dragging = false;
    delete stage.dataset.dragging;
    if (stage.hasPointerCapture(event.pointerId)) stage.releasePointerCapture(event.pointerId);
    // Momentum: carry the release velocity round the orbit, then settle on a card.
    const first = samples[0];
    const elapsed = event.timeStamp - first.t;
    const velocity = elapsed > 0 && event.type === "pointerup" ? (event.clientX - first.x) / elapsed : 0; // px per ms
    // A short controlled glide. Do not skip 3-4 cards after a flick.
    const glide = (-velocity * 1000 * 0.14) / stride();
    target = Math.round(current + clamp(glide, -MAX_GLIDE, MAX_GLIDE));
    setHovered(-1);
    kick();
  }

  function onPointerEnter() {
    pointerInside = true;
  }

  function onPointerLeave() {
    pointerInside = false;
    if (!dragging) setHovered(-1);
  }

  // A drag ends on a card: that release is not a click.
  function onClickCapture(event: MouseEvent) {
    if (!moved) return;
    event.preventDefault();
    event.stopPropagation();
    moved = false;
  }

  // Horizontal wheel and trackpad swipes only: vertical scrolling stays the page's.
  function onWheel(event: WheelEvent) {
    if (pressed || dragging) return;
    const delta = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.shiftKey ? event.deltaY : 0;
    if (!delta || count < 2) return;
    event.preventDefault();
    announce = true;
    target += delta / stride();
    kick();
    window.clearTimeout(wheelTimer);
    wheelTimer = window.setTimeout(() => {
      target = Math.round(target);
      kick();
    }, 160);
  }

  function onKeyDown(event: KeyboardEvent) {
    const moves: Record<string, number> = { ArrowLeft: -1, ArrowRight: 1 };
    if (!(event.key in moves)) return;
    event.preventDefault();
    stepBy(moves[event.key], true);
    // Keyboard focus travels with the orbit when it is on a card.
    if (slotIndex(document.activeElement) >= 0) {
      const index = (((Math.round(target) % count) + count) % count);
      slots[index]?.querySelector<HTMLElement>("a")?.focus({ preventScroll: true });
    }
  }

  function onFocusIn(event: FocusEvent) {
    focusInside = true;
    const index = slotIndex(event.target);
    if (index >= 0 && (event.target as Element).matches(":focus-visible")) {
      announce = true;
      goTo(index);
    }
  }

  function onFocusOut(event: FocusEvent) {
    focusInside = stage.contains(event.relatedTarget as Node | null);
  }

  /** Rebuilds the orbit from the measured card and stage. */
  function measure() {
    const cardWidth = slots.find(Boolean)?.offsetWidth;
    if (!cardWidth || count === 0) return;
    layout = createOrbitLayout({
      cardWidth,
      perspective: PERSPECTIVE,
      gap: stage.clientWidth < COMPACT_WIDTH ? GAP_COMPACT : GAP,
      depth: ORBIT_DEPTH,
      shrink: DEPTH_SHRINK,
      count,
    });
    render();
  }

  // A slow auto-rotation, paused whenever the visitor is interacting or away.
  const autoRotate = reduced
    ? 0
    : window.setInterval(() => {
        if (pointerInside || focusInside || pressed || !onScreen || document.hidden || intro.value < 1) return;
        stepBy(1, false);
      }, AUTO_ROTATE * 1000);

  const visibility = new IntersectionObserver(([entry]) => {
    onScreen = entry.isIntersecting;
  });
  visibility.observe(stage);

  const resize = new ResizeObserver(measure);
  resize.observe(stage);
  stage.addEventListener("pointerdown", onPointerDown);
  stage.addEventListener("pointermove", onPointerMove);
  stage.addEventListener("pointerup", onPointerUp);
  stage.addEventListener("pointercancel", onPointerUp);
  stage.addEventListener("pointerenter", onPointerEnter);
  stage.addEventListener("pointerleave", onPointerLeave);
  stage.addEventListener("click", onClickCapture, true);
  stage.addEventListener("wheel", onWheel, { passive: false });
  stage.addEventListener("keydown", onKeyDown);
  stage.addEventListener("focusin", onFocusIn);
  stage.addEventListener("focusout", onFocusOut);
  stage.addEventListener("dragstart", preventDefault);

  let introTween: gsap.core.Tween | undefined;
  const stopReveal = onIntroReveal(() => {
    if (reduced) return;
    introTween = gsap.to(intro, { value: 1, duration: 2, delay: 0.35, ease: EASE, onUpdate: kick });
  });

  return {
    setCount(next) {
      const refilter = count > 0;
      count = next;
      setHovered(-1);
      // A new orbit starts with its first role at the front.
      current = target = 0;
      activeIndex = -1;
      announce = false;
      measure();
      // A filtered set settles into its orbit from slightly deeper.
      if (refilter && !reduced && intro.value === 1) {
        introTween?.kill();
        introTween = gsap.fromTo(intro, { value: 0.55 }, { value: 1, duration: 1.2, ease: EASE, onUpdate: kick });
      }
      kick();
    },
    step(delta) {
      stepBy(delta, true);
    },
    destroy() {
      cancelAnimationFrame(frame);
      window.clearTimeout(wheelTimer);
      window.clearInterval(autoRotate);
      stopReveal();
      introTween?.kill();
      resize.disconnect();
      visibility.disconnect();
      stage.removeEventListener("pointerdown", onPointerDown);
      stage.removeEventListener("pointermove", onPointerMove);
      stage.removeEventListener("pointerup", onPointerUp);
      stage.removeEventListener("pointercancel", onPointerUp);
      stage.removeEventListener("pointerenter", onPointerEnter);
      stage.removeEventListener("pointerleave", onPointerLeave);
      stage.removeEventListener("click", onClickCapture, true);
      stage.removeEventListener("wheel", onWheel);
      stage.removeEventListener("keydown", onKeyDown);
      stage.removeEventListener("focusin", onFocusIn);
      stage.removeEventListener("focusout", onFocusOut);
      stage.removeEventListener("dragstart", preventDefault);
    },
  };
}
