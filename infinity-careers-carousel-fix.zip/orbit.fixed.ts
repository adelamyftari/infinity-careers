/**
 * Infinity Careers — projection-corrected infinite 3D orbit.
 *
 * All jobs have equal angular separation on a continuous circular X/Z orbit.
 * Perspective makes the visible gaps shrink toward the sides, so the
 * FRONT ARC receives a smooth screen-space X correction for even spacing.
 * The back (not visible) remains a true circle. The correction prevents
 * neighbouring cards from slicing through each other midway through drag.
 *
 * IMPORTANT: The parent of the cards must have one shared CSS perspective.
 */

const TAU = Math.PI * 2;
const DEG = Math.PI / 180;
const clamp = (n: number, a: number, b: number) => Math.min(b, Math.max(a, n));
const smoothstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / Math.max(b - a, 1e-6), 0, 1);
  return t * t * (3 - 2 * t);
};

export type OrbitOptions = {
  cardWidth: number;
  perspective: number;
  gap: number;
  depth: number;
  shrink: number;
  count: number;
};

export type CardPlacement = {
  x: number;
  z: number;
  rotateY: number;
  scale: number;
  fade: number;
  opacity: number;
  zIndex: number;
};

export type OrbitLayout = {
  radiusX: number;
  radiusZ: number;
  stride: number;
  place: (offset: number) => CardPlacement;
};

export function createOrbitLayout({ cardWidth, perspective, gap, depth, shrink, count }: OrbitOptions): OrbitLayout {
  const n = Math.max(1, count);
  const step = TAU / n;
  const w = Math.max(1, cardWidth);
  const camera = Math.max(700, perspective);
  const depthFactor = clamp(depth, 0.35, 0.85);
  const depthShrink = clamp(shrink, 0, 0.2);
  const radiusX = n > 2 ? Math.max(w * 1.65, (w + gap) / (2 * Math.sin(Math.min(step / 2, Math.PI / 3)))) : w * 1.2;
  const radiusZ = radiusX * depthFactor;

  // An edge-on tangent rotation was creating ugly vertical strips.
  const yaw = (theta: number) => clamp(theta * 0.33, -37 * DEG, 37 * DEG);
  const cardScale = (theta: number) => 1 - depthShrink * (1 - Math.cos(theta)) / 2;
  const zAt = (theta: number) => radiusZ * (Math.cos(theta) - 1);

  // At a 12-card orbit: front and adjacent cards stay readable, while
  // the second neighbour gradually fades rather than clipping abruptly.
  const fadeFrom = Math.min(0.78 * step, 29 * DEG);
  const fadeTo = Math.min(2.1 * step, 73 * DEG);

  /** Project the card's left and right edges through the SAME camera. */
  function edgeProjection(theta: number, worldX = 0) {
    const scale = cardScale(theta);
    const turn = yaw(theta);
    const z = zAt(theta);
    const half = w * scale / 2;
    const leftZ = z + half * Math.sin(turn);
    const rightZ = z - half * Math.sin(turn);
    const leftFactor = camera / (camera - leftZ);
    const rightFactor = camera / (camera - rightZ);
    const left = (worldX - half * Math.cos(turn)) * leftFactor;
    const right = (worldX + half * Math.cos(turn)) * rightFactor;
    return { left, right, leftFactor, rightFactor, turn, half };
  }

  // Integrate projected card width along the visible front arc. The center
  // of each card advances by approximately half the preceding/next widths
  // plus the desired gap, even during fractional dragging (e.g. 0.25, 0.5).
  // Precalculate this lookup once per ResizeObserver measurement, not per frame.
  const maxLookup = Math.min(n / 2, Math.max(2.5, fadeTo / step + 0.5));
  const divisions = 512;
  const dx = maxLookup / divisions;
  const integrated = new Float64Array(divisions + 1);
  const projectedWidth = (d: number) => {
    const e = edgeProjection(d * step);
    return e.right - e.left;
  };
  let lastWidth = projectedWidth(0);
  for (let i = 1; i <= divisions; i++) {
    const nextWidth = projectedWidth(i * dx);
    integrated[i] = integrated[i - 1] + ((lastWidth + nextWidth) / 2 + gap) * dx;
    lastWidth = nextWidth;
  }

  function screenCenter(offset: number) {
    const sign = Math.sign(offset);
    const d = clamp(Math.abs(offset), 0, maxLookup);
    const pos = d / dx;
    const i = Math.min(divisions - 1, Math.floor(pos));
    const mix = pos - i;
    return sign * (integrated[i] * (1 - mix) + integrated[i + 1] * mix);
  }

  function place(offset: number): CardPlacement {
    const theta = offset * step;
    const z = zAt(theta);
    const angle = Math.abs(theta);
    const projection = edgeProjection(theta);
    const widthFactor = (projection.leftFactor + projection.rightFactor) / 2;
    const asymmetricShift = (projection.left + projection.right) / 2;
    // Invert the shared perspective, including different perspective factors
    // for the rotated left/right edges, to hit the desired screen-space center.
    const correctedX = (screenCenter(offset) - asymmetricShift) / widthFactor;
    const circularX = radiusX * Math.sin(theta);
    // Once a card is invisible behind the front arc, return to the true ring.
    const returnToCircle = smoothstep(fadeTo, fadeTo + 12 * DEG, angle);
    const x = correctedX * (1 - returnToCircle) + circularX * returnToCircle;
    const towardBack = smoothstep(fadeFrom, fadeTo, angle);
    return {
      x,
      z,
      rotateY: yaw(theta) / DEG,
      scale: cardScale(theta),
      fade: towardBack * 0.82,
      opacity: clamp(1 - towardBack, 0, 1),
      zIndex: Math.round(100_000 + z),
    };
  }

  return {
    radiusX,
    radiusZ,
    stride: Math.max(180, w * 0.75),
    place,
  };
}
