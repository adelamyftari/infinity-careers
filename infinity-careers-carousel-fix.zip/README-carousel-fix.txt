Infinity Careers — Job Carousel Geometry & Drag Fix
=================================================

FILES
- orbit.fixed.ts         -> replace src/lib/carousel/orbit.ts
- JobCarousel.fixed.tsx  -> replace your existing JobCarousel.tsx (keep its actual path)

WHAT CHANGED
- One shared CSS perspective on the orbital parent.
- Projection-corrected front arc for steady gaps during fractional drag.
- Continuous 360-degree X/Z orbit behind the visible arc.
- Softer side yaw to avoid cards collapsing into vertical strips.
- Smooth depth-based opacity/fade toward the rear.
- Pointer down now starts from the actual rendered angle, preventing jumps.
- Limited release momentum (0.65 card instead of 4 extra cards).
- Reduced hover lift to keep neighboring cards unobstructed.
- Card image/title/cutout/external glass CTA travel as one card unit.
- Existing filters, card design, images and other page sections unchanged.

VALIDATION
- orbit.fixed.ts transpiled with TypeScript 5.8.3.
- Geometry was mathematically checked for 2–18 cards across the full
  transition (101 sampled drag positions). No overlaps among cards whose
  opacity exceeds 0.1; the 12-card case had visible gaps ~47–89px for
  560px cards with 1600px shared perspective.
- Full Next.js build and real browser tests were NOT possible without the
  complete project, JobCard.tsx and its dependencies.

AFTER INSTALLING
1. Stop dev server (Ctrl+C), replace both files, restart `npm run dev`.
2. Test slow drag, fast drag, arrow keys, 12 cards and filtered sets.
3. If you want more or less spacing, adjust GAP in JobCarousel.tsx.
4. Keep the existing JobCard component unchanged.
